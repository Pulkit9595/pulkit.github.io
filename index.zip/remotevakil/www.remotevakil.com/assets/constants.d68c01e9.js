typeof window<"u"&&(window==null||window.localStorage.getItem("mixo-admin"));
